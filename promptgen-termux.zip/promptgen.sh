#!/data/data/com.termux/files/usr/bin/bash

echo 'PromptGen Termux siap digunakan!'